// Smooth Scroll for navigation

document.querySelectorAll("nav a").forEach(anchor => {

  anchor.addEventListener("click", function(e) {

    e.preventDefault();

    document.querySelector(this.getAttribute("href")).scrollIntoView({

      behavior: "smooth"

    });

  });

});

// Simple welcome alert

window.onload = function() {

  alert("Welcome to Sabeena's Portfolio!");

};